﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public partial class MainWindow : Window
        {
            public MainWindow()
            {
                InitializeComponent();
            }

            private void muveletvegrehajtasa_Click(object sender, RoutedEventArgs e)
            {
                double szam1;
                double szam2;
                string eredmeny = "";

                if (double.TryParse(adat1box.Text, out szam1) && double.TryParse(adat2box.Text, out szam2))
                {
                    switch (muveletijelbox.Text)
                    {
                        case "+": eredmeny = osszeadas(szam1, szam2); break;
                        case "-": eredmeny = kivonas(szam1, szam2); break;
                        case "*": eredmeny = szorzas(szam1, szam2); break;
                        case "/": eredmeny = osztas(szam1, szam2); break;
                        default: MessageBox.Show("Rossz műveleti jel"); return;
                    }
                    if (eredmeny == "végtelen")
                    {
                        MessageBox.Show("0 az osztandó értéke!", "Hiba", MessageBoxButton.OK);
                    }
                }
                else
                {
                    MessageBox.Show("Rossz számok");
                }

                muveleteredmenyebox.Text = eredmeny;
            }

            private string osszeadas(double szam1, double szam2)
            {
                double eredmeny = szam1 + szam2;
                return eredmeny.ToString();
            }
            private string kivonas(double szam1, double szam2)
            {
                double eredmeny = szam1 - szam2;
                return eredmeny.ToString();
            }

            private string szorzas(double szam1, double szam2)
            {
                double eredmeny = szam1 * szam2;
                return eredmeny.ToString();
            }
            private string osztas(double szam1, double szam2)
            {
                if (szam2 != 0)
                {
                    double eredmeny = szam1 / szam2;
                    return eredmeny.ToString();
                }
                else
                {
                    return "végtelen";
                }

            }
        }
    }
}
