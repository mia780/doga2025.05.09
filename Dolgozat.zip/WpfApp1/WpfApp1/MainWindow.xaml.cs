﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void szamol_Click(object sender, RoutedEventArgs e)
        {
            double sz1;
            double sz2;

            if (double.TryParse(szam1box.Text, out sz1) && double.TryParse(szam2box.Text, out sz2))
            {
                double mertani = Math.Sqrt(sz1 * sz2);
                double szamtani = (sz1 + sz2) / 2;
                mertanikozepbox.Text = mertani.ToString();
                szamtanikozepbox.Text = szamtani.ToString();
            }
            else
            {
                MessageBox.Show("Nem jó az egyik szám.");
            }
        }

    }
}
